# Personal Expense Tracker with Data Analytics

A local Python command-line mini project that records expenses in SQLite and produces monthly category summaries, budget alerts, CSV exports, and optional Matplotlib charts.

## Requirements
- Python 3.9 or newer
- Optional for chart generation: `pip install matplotlib`

## Start
```bash
python expense_tracker.py init
python expense_tracker.py add 2026-10-09 Food 120 --note "Lunch"
python expense_tracker.py report 2026-10 --budget 2000
```

## Reproduce the fictional sample output
```bash
python expense_tracker.py --db expense_demo.db demo
python expense_tracker.py --db expense_demo.db chart 2026-10 category_chart.png
python expense_tracker.py --db expense_demo.db export expenses.csv
```

The `demo` command inserts the six fictional example transactions into an **empty database only**; it does not reinsert examples into an existing nonempty database. Demo figures are not real financial data.

## Submission notes
The accompanying PDF follows the supplied college mini-project format and leaves the student name and registration number blank. The report's GitHub URL is a placeholder and must be replaced with a real, verified repository address after upload.
