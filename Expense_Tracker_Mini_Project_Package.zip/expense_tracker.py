"""Personal Expense Tracker with Data Analytics.

Python 3.9+; SQLite storage; optional matplotlib only for charts.
Example: python expense_tracker.py --db demo_expenses.db demo
"""
import argparse
import csv
import sqlite3
from datetime import date
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from pathlib import Path

CATEGORIES = (
    "Food", "Transport", "Groceries", "Education",
    "Entertainment", "Healthcare", "Utilities", "Other",
)


def connect(db_path):
    connection = sqlite3.connect(db_path)
    connection.execute(
        """CREATE TABLE IF NOT EXISTS expenses (
               id INTEGER PRIMARY KEY AUTOINCREMENT,
               expense_date TEXT NOT NULL,
               category TEXT NOT NULL,
               amount_paise INTEGER NOT NULL CHECK(amount_paise > 0),
               note TEXT NOT NULL DEFAULT ''
           )"""
    )
    connection.commit()
    return connection


def money_to_paise(value):
    try:
        amount = Decimal(str(value))
    except InvalidOperation as error:
        raise ValueError("Amount must be numeric.") from error
    if not amount.is_finite() or amount <= 0:
        raise ValueError("Amount must be positive and finite.")
    paise = int((amount * 100).quantize(Decimal("1"), rounding=ROUND_HALF_UP))
    if paise < 1:
        raise ValueError("Amount must be at least INR 0.01.")
    return paise


def rupees(paise):
    return f"INR {paise / 100:,.2f}"


def add_expense(db, expense_date, category, amount, note=""):
    date.fromisoformat(expense_date)  # Rejects invalid calendar dates.
    if category not in CATEGORIES:
        raise ValueError("Choose a category from: " + ", ".join(CATEGORIES))
    paise = money_to_paise(amount)
    db.execute(
        "INSERT INTO expenses (expense_date, category, amount_paise, note) "
        "VALUES (?, ?, ?, ?)",
        (expense_date, category, paise, note.strip()),
    )
    db.commit()


def monthly_summary(db, month):
    date.fromisoformat(month + "-01")  # YYYY-MM, including valid month.
    records = db.execute(
        "SELECT category, COUNT(*), SUM(amount_paise) FROM expenses "
        "WHERE substr(expense_date, 1, 7) = ? "
        "GROUP BY category ORDER BY SUM(amount_paise) DESC, category",
        (month,),
    ).fetchall()
    return records


def print_report(db, month, budget=None):
    records = monthly_summary(db, month)
    count = sum(row[1] for row in records)
    total = sum(row[2] for row in records)
    print(f"\nEXPENSE REPORT | {month}")
    print("-" * 49)
    print(f"{'Category':<18} {'Items':>5} {'Amount':>21}")
    for category, items, paise in records:
        print(f"{category:<18} {items:>5} {rupees(paise):>21}")
    print("-" * 49)
    print(f"Transactions: {count}  |  Total: {rupees(total)}")
    if budget is not None:
        budget_paise = money_to_paise(budget)
        share = 100 * total / budget_paise
        if total > budget_paise:
            state = "OVER BUDGET"
        elif share >= 80:
            state = "CAUTION (80% or more used)"
        else:
            state = "WITHIN BUDGET"
        print(f"Budget: {rupees(budget_paise)} | Used: {share:.1f}%")
        print(f"Status: {state}")
    if not records:
        print("No recorded expenses for this month.")


def export_csv(db, filename):
    rows = db.execute(
        "SELECT expense_date, category, amount_paise, note "
        "FROM expenses ORDER BY expense_date, id"
    ).fetchall()
    with open(filename, "w", newline="", encoding="utf-8") as file:
        writer = csv.writer(file)
        writer.writerow(["Date", "Category", "Amount_INR", "Note"])
        for day, category, paise, note in rows:
            writer.writerow([day, category, f"{paise / 100:.2f}", note])
    print(f"Exported {len(rows)} transactions to {filename}")


def save_chart(db, month, filename):
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError as error:
        raise RuntimeError("Install matplotlib to generate a chart.") from error
    rows = monthly_summary(db, month)
    if not rows:
        raise ValueError("No expenses available for the selected month.")
    labels = [row[0] for row in rows]
    amounts = [row[2] / 100 for row in rows]
    fig, ax = plt.subplots(figsize=(8, 4.3))
    bars = ax.bar(labels, amounts, color="#336e9b")
    ax.bar_label(bars, fmt="%.2f", padding=3, fontsize=9)
    ax.set_ylabel("Amount (INR)")
    ax.set_title(f"Expenses by Category - {month}")
    ax.tick_params(axis="x", labelrotation=20)
    ax.set_ylim(0, max(amounts) * 1.2)
    fig.tight_layout()
    fig.savefig(filename, dpi=150)
    plt.close(fig)
    print(f"Saved category chart to {filename}")


def load_demo(db):
    examples = [
        ("2026-10-02", "Food", "230.00", "Lunch"),
        ("2026-10-03", "Transport", "80.00", "Bus fare"),
        ("2026-10-04", "Groceries", "620.50", "Groceries"),
        ("2026-10-05", "Education", "450.00", "Notebooks"),
        ("2026-10-06", "Food", "180.00", "Dinner"),
        ("2026-10-07", "Entertainment", "300.00", "Movie"),
    ]
    if db.execute("SELECT COUNT(*) FROM expenses").fetchone()[0] != 0:
        print("Demo skipped: database already contains expenses.")
        return
    for day, category, amount, note in examples:
        add_expense(db, day, category, amount, note)
    print(f"Inserted {len(examples)} fictional demonstration expenses.")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--db", default="expenses.db", help="SQLite file")
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("init", help="Create the database")
    sub.add_parser("demo", help="Insert fictional data and print a report")
    add = sub.add_parser("add", help="Record one expense")
    add.add_argument("day", help="YYYY-MM-DD")
    add.add_argument("category", choices=CATEGORIES)
    add.add_argument("amount", help="Positive amount in INR")
    add.add_argument("--note", default="")
    report = sub.add_parser("report", help="Monthly totals")
    report.add_argument("month", help="YYYY-MM")
    report.add_argument("--budget", help="Optional monthly budget in INR")
    export = sub.add_parser("export", help="Export all records")
    export.add_argument("filename")
    chart = sub.add_parser("chart", help="Save category bar chart")
    chart.add_argument("month")
    chart.add_argument("filename")
    args = parser.parse_args()
    with connect(Path(args.db)) as db:
        try:
            if args.command == "init":
                print(f"Database ready: {args.db}")
            elif args.command == "add":
                add_expense(db, args.day, args.category, args.amount, args.note)
                print("Expense saved successfully.")
            elif args.command == "report":
                print_report(db, args.month, args.budget)
            elif args.command == "export":
                export_csv(db, args.filename)
            elif args.command == "chart":
                save_chart(db, args.month, args.filename)
            elif args.command == "demo":
                load_demo(db)
                print_report(db, "2026-10", "2000")
        except (ValueError, RuntimeError) as error:
            parser.error(str(error))


if __name__ == "__main__":
    main()
